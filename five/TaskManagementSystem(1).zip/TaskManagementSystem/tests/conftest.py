import pytest
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.firefox.service import Service as FirefoxService
from selenium.webdriver.edge.service import Service as EdgeService
from webdriver_manager.chrome import ChromeDriverManager
from webdriver_manager.firefox import GeckoDriverManager
from webdriver_manager.microsoft import EdgeChromiumDriverManager
import logging
import os
from datetime import datetime

# Configure logging
logging.basicConfig(
    filename='test_execution.log',
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

def pytest_configure(config):
    # Create screenshots directory if it doesn't exist
    if not os.path.exists('screenshots'):
        os.makedirs('screenshots')

@pytest.fixture(params=['chrome', 'firefox', 'edge'])
def driver(request):
    browser = request.param
    
    if browser == 'chrome':
        chrome_options = webdriver.ChromeOptions()
        # chrome_options.add_argument('--headless')  # Uncomment for headless execution
        driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=chrome_options)
    elif browser == 'firefox':
        firefox_options = webdriver.FirefoxOptions()
        # firefox_options.add_argument('--headless')  # Uncomment for headless execution
        driver = webdriver.Firefox(service=FirefoxService(GeckoDriverManager().install()), options=firefox_options)
    elif browser == 'edge':
        edge_options = webdriver.EdgeOptions()
        # edge_options.add_argument('--headless')  # Uncomment for headless execution
        driver = webdriver.Edge(service=EdgeService(EdgeChromiumDriverManager().install()), options=edge_options)
    
    driver.implicitly_wait(10)  # Implicit wait for all tests
    driver.maximize_window()
    
    logging.info(f"Starting test with {browser} browser")
    
    yield driver
    
    # Capture screenshot on test failure
    if request.node.rep_call.failed:
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        screenshot_name = f"failure_{request.node.name}_{browser}_{timestamp}.png"
        driver.save_screenshot(os.path.join('screenshots', screenshot_name))
        logging.error(f"Test failed. Screenshot saved as {screenshot_name}")
    
    driver.quit()
    logging.info(f"Finished test with {browser} browser")

@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    outcome = yield
    rep = outcome.get_result()
    setattr(item, "rep_" + rep.when, rep)

