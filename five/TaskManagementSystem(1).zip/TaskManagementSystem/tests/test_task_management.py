import pytest
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import Select
from selenium.common.exceptions import TimeoutException
import logging
from selenium.webdriver.common.action_chains import ActionChains
import time

class TestTaskManagement:
    BASE_URL = "http://localhost:5000"
    
    def test_login_page_elements(self, driver):
        """Test 1: Finding web elements using different methods"""
        logging.info("Starting login page elements test")
        
        driver.get(f"{self.BASE_URL}/login")
        
        # Find by ID
        email_input = driver.find_element(By.ID, "email")
        
        # Find by CSS selector
        password_input = driver.find_element(By.CSS_SELECTOR, "input[type='password']")
        
        # Find by XPath
        login_button = driver.find_element(By.XPATH, "//button[contains(text(), 'Login')]")
        
        # Find by link text
        signup_link = driver.find_element(By.LINK_TEXT, "Sign Up")
        
        # Send keys and verify text
        email_input.send_keys("test@example.com")
        assert email_input.get_attribute("value") == "test@example.com"
        
        logging.info("Login page elements test completed")

    def test_checkbox_and_radio(self, driver):
        """Test 2: Testing checkbox and radio button operations"""
        logging.info("Starting checkbox and radio button test")
        
        driver.get(f"{self.BASE_URL}/dashboard")
        
        # Test radio buttons
        alone_radio = driver.find_element(By.ID, "alone")
        family_radio = driver.find_element(By.ID, "family")
        
        alone_radio.click()
        assert alone_radio.is_selected()
        assert not family_radio.is_selected()
        
        # Test task completion checkbox
        task_checkbox = driver.find_element(By.CLASS_NAME, "task-completion-toggle")
        task_checkbox.click()
        assert task_checkbox.is_selected()
        
        logging.info("Checkbox and radio button test completed")

    def test_dropdown_menus(self, driver):
        """Test 3: Testing dropdown menu operations"""
        logging.info("Starting dropdown menu test")
        
        driver.get(f"{self.BASE_URL}/dashboard")
        
        # Test priority dropdown
        priority_dropdown = Select(driver.find_element(By.ID, "priority"))
        priority_dropdown.select_by_visible_text("High")
        assert priority_dropdown.first_selected_option.text == "High"
        
        # Test filter dropdowns
        category_filter = Select(driver.find_element(By.ID, "filter-category"))
        priority_filter = Select(driver.find_element(By.ID, "filter-priority"))
        status_filter = Select(driver.find_element(By.ID, "filter-status"))
        
        category_filter.select_by_index(1)
        priority_filter.select_by_value("High")
        status_filter.select_by_visible_text("Completed")
        
        logging.info("Dropdown menu test completed")

    def test_wait_conditions(self, driver):
        """Test 4: Testing different wait conditions"""
        logging.info("Starting wait conditions test")
        
        driver.get(f"{self.BASE_URL}/dashboard")
        wait = WebDriverWait(driver, 10)
        
        # Explicit wait for element presence
        add_task_form = wait.until(
            EC.presence_of_element_located((By.ID, "addTaskForm"))
        )
        
        # Wait for element to be visible
        task_list = wait.until(
            EC.visibility_of_element_located((By.ID, "task-list"))
        )
        
        # Wait for element to be clickable
        submit_button = wait.until(
            EC.element_to_be_clickable((By.CSS_SELECTOR, "button[type='submit']"))
        )
        
        # Dynamic content loading test
        try:
            task_items = wait.until(
                EC.presence_of_all_elements_located((By.CLASS_NAME, "task-item"))
            )
            logging.info(f"Found {len(task_items)} task items")
        except TimeoutException:
            logging.error("Timeout waiting for task items to load")
            raise
        
        logging.info("Wait conditions test completed")

    def test_advanced_interactions(self, driver):
        """Test 5: Testing iframes, windows, and JavaScript operations"""
        logging.info("Starting advanced interactions test")
        
        driver.get(f"{self.BASE_URL}/dashboard")
        
        # Execute JavaScript
        driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
        
        # Check element states
        submit_button = driver.find_element(By.CSS_SELECTOR, "button[type='submit']")
        assert submit_button.is_enabled()
        
        # Get element coordinates and size
        task_list = driver.find_element(By.ID, "task-list")
        location = task_list.location
        size = task_list.size
        logging.info(f"Task list location: {location}, size: {size}")
        
        # Open statistics in new window
        stats_link = driver.find_element(By.LINK_TEXT, "Task Statistics")
        stats_link.click()
        
        # Switch to new window
        wait = WebDriverWait(driver, 10)
        wait.until(lambda d: len(d.window_handles) > 1)
        driver.switch_to.window(driver.window_handles[-1])
        
        # Verify statistics page
        assert "Task Statistics" in driver.title
        
        logging.info("Advanced interactions test completed")

    def test_cross_browser_compatibility(self, driver):
        """Test 6: Testing cross-browser compatibility"""
        logging.info(f"Starting cross-browser test with {driver.name}")
        
        driver.get(f"{self.BASE_URL}/dashboard")
        
        # Test responsive design
        window_sizes = [(1920, 1080), (1366, 768), (375, 812)]  # Desktop, Laptop, Mobile
        
        for width, height in window_sizes:
            driver.set_window_size(width, height)
            task_list = driver.find_element(By.ID, "task-list")
            assert task_list.is_displayed()
            logging.info(f"Tested responsive design at {width}x{height}")
        
        logging.info("Cross-browser compatibility test completed")

    def test_screenshot_functionality(self, driver):
        """Test 7: Testing screenshot functionality"""
        logging.info("Starting screenshot test")
        
        driver.get(f"{self.BASE_URL}/dashboard")
        
        # Take screenshots of different states
        driver.save_screenshot("screenshots/dashboard_initial.png")
        
        # Add a task and take screenshot
        title_input = driver.find_element(By.ID, "title")
        title_input.send_keys("Test Task")
        driver.save_screenshot("screenshots/dashboard_with_input.png")
        
        logging.info("Screenshot test completed")

    def test_logging_functionality(self, driver):
        """Test 8: Testing logging functionality"""
        logging.info("Starting logging test")
        
        try:
            driver.get(f"{self.BASE_URL}/dashboard")
            logging.info("Successfully loaded dashboard")
            
            # Log various actions
            title_input = driver.find_element(By.ID, "title")
            logging.info("Found title input field")
            
            title_input.send_keys("Test Task")
            logging.info("Entered test task title")
            
        except Exception as e:
            logging.error(f"Error during test: {str(e)}")
            raise
        
        logging.info("Logging test completed")

    def test_pytest_features(self, driver):
        """Test 9: Testing with pytest features"""
        logging.info("Starting pytest features test")
        
        driver.get(f"{self.BASE_URL}/dashboard")
        
        # Test fixtures (driver is already a fixture)
        assert driver is not None
        
        # Test assertions
        title_input = driver.find_element(By.ID, "title")
        assert title_input.is_displayed()
        assert title_input.get_attribute("required") == "true"
        
        # Test parametrize (example)
        test_data = [
            ("Test Task 1", "High"),
            ("Test Task 2", "Medium"),
            ("Test Task 3", "Low")
        ]
        
        for title, priority in test_data:
            title_input.clear()
            title_input.send_keys(title)
            Select(driver.find_element(By.ID, "priority")).select_by_visible_text(priority)
            assert title_input.get_attribute("value") == title
        
        logging.info("Pytest features test completed")

